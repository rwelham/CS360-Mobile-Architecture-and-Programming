package com.example.eventtrackingremywelham;

// imports for android and SQL lite database
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

// imports for needed java classes
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EventTrackerDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "eventtracker.db";
    private static final int VERSION = 1;

    private static EventTrackerDatabase eventTrackerDB;

    // creates database if none exists
    public static EventTrackerDatabase getInstance(Context context){
        if (eventTrackerDB == null){
            eventTrackerDB = new EventTrackerDatabase(context);
        }
        return eventTrackerDB;
    }

    // constructor
    public EventTrackerDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // table schema for Users
    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_SMS_PERM = "smsperm";
    }

    // table schema for Events
    private static final class EventTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_TITLE = "title";
        private static final String COL_DATE = "date";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_EVENT_USER = "eventuser";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        // create the user table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PASSWORD + " text, " +
                UserTable.COL_SMS_PERM + " integer)");

        // create the event table
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_TITLE + " text, " +
                EventTable.COL_DATE + " integer, " +
                EventTable.COL_DESCRIPTION + " text, " +
                EventTable.COL_EVENT_USER + " text, " +
                "foreign key(" + UserTable.COL_USERNAME + ") REFERENCES users (username) ON delete cascade)");

        // add admin account
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, "admin");
        values.put(UserTable.COL_PASSWORD, "12345");
        values.put(UserTable.COL_SMS_PERM, "1");
        db.insert(UserTable.TABLE, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db = getWritableDatabase();
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + EventTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN){
                db.execSQL("pragma foreign_keys = on;");
            }
            else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    // return user information
    public User getUser(String username){
        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                " where " + UserTable.COL_USERNAME + " = '" +
                username + "'";
        // cursor to parse db results and user to return
        Cursor cursor = db.rawQuery(sql, null);
        User user = new User();
        // gets user info
        if (cursor.moveToFirst()){
            do{
                user.setUsername(cursor.getString(0));
                user.setPassword(cursor.getString(1));
                user.setSmsPerm(cursor.getInt(2));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return user;
    }

    // add new User to table
    public boolean addUser(User user){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        values.put(UserTable.COL_SMS_PERM, user.getSmsPerm());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1; // if -1, add user failed
    }

    // register new User
    public boolean registerUser(User user){
        SQLiteDatabase db = this.getReadableDatabase();
        final String USERNAME = user.getUsername();
        // checks username is there
        if(!USERNAME.isEmpty()){
            // sql query
            String sql = "select " + UserTable.COL_USERNAME + " from " + UserTable.TABLE +
                    " where " + UserTable.COL_USERNAME + " = '" + user.getUsername() + "'";
            Cursor cursor = db.rawQuery(sql, null);
            if(cursor.moveToFirst()){
                return false;
            } else {
                this.addUser(user);
                return true;
            }
        } else {
            return false;
        }
    }

    //check user on login
    public boolean authenticateUser(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        final String USERNAME = user.getUsername();
        final String PASSWORD = user.getPassword();

        String sql = "select * from " + UserTable.TABLE +
                " where " + UserTable.COL_USERNAME + " = '" +
                user.getUsername() + "'";
        Cursor cursor = db.rawQuery(sql, null);
        if(!cursor.moveToFirst()) {
            return false;
        } else {
            return cursor.getString(0).equals(USERNAME) &&
                    cursor.getString(1).equals(PASSWORD);
        }
    }

    // get a list of events
    public List<Event> getEvents(String username){
        List<Event> events = new ArrayList<>(); // list of events to be returned
        SQLiteDatabase db = this.getReadableDatabase(); // database access
        final String listOrder = EventTable.COL_DATE + " asc"; // list events by ascending date order
        // sql query for searching
        String sql = "select * from " + EventTable.TABLE +
                " where " + EventTable.COL_EVENT_USER +
                " = '" + username + "' order by " + listOrder;
        Cursor cursor = db.rawQuery(sql, null); // cursor for navigating db
        // if there's a next entry, get details from each column and pass to event object
        if(cursor.moveToFirst()){
            do {
                Event event = new Event();
                event.setId(cursor.getInt(0));
                event.setTitle(cursor.getString(1));
                Calendar cal = formatDate(cursor.getLong(2));
                event.setDate(cal);
                event.setDescription(cursor.getString(3));
                event.setEventUser(cursor.getString(4));
                events.add(event);
            } while (cursor.moveToNext());
        }

        cursor.close(); // close
        return events; // return list
    }

    public Event getEvent(int id) {
        SQLiteDatabase db = this.getReadableDatabase(); // opens database
        Event event = new Event(); // event to be returned
        // query for database
        String sql = "select * from " + EventTable.TABLE +
                " where " + EventTable.COL_ID + " = " + id;
        Cursor cursor = db.rawQuery(sql, null);
        // if there's a first entry, get details from query
        if(cursor.moveToFirst()){
            do {
                event.setId(cursor.getInt(0));
                event.setTitle(cursor.getString(1));
                Calendar cal = formatDate(cursor.getLong(2));
                event.setDate(cal);
                event.setDescription(cursor.getString(3));
                event.setEventUser(cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return event; // return found event or empty event
    }

    // add event from event object
    public void addEvent(Event event){
        SQLiteDatabase db = getWritableDatabase(); // open db to write to
        ContentValues values = new ContentValues();
        Calendar eventDate = event.getDate();
        String formatDate = Integer.toString(eventDate.get(Calendar.YEAR)) +
                String.format("%02d", eventDate.get(Calendar.MONTH)) +
                String.format("%02d", eventDate.get(Calendar.DAY_OF_MONTH)) +
                String.format("%02d", eventDate.get(Calendar.HOUR_OF_DAY)) +
                String.format("%02d", eventDate.get(Calendar.MINUTE));

        values.put(EventTable.COL_TITLE, event.getTitle());
        values.put(EventTable.COL_DATE, Long.parseLong(formatDate));
        values.put(EventTable.COL_DESCRIPTION, event.getDescription());
        values.put(EventTable.COL_EVENT_USER, event.getEventUser());
        long id = db.insert(EventTable.TABLE, null, values); // get id from adding event
        event.setId(Math.toIntExact(id)); // set id for event

    }

    // delete event given event object
    public void deleteEvent(Event event){
        SQLiteDatabase db = getWritableDatabase(); // open database to write
        // deletes event row by id
        db.delete(EventTable.TABLE, EventTable.COL_ID +
                " = ?", new String[] {Integer.toString(event.getId())});
    }

    private Calendar formatDate(long lDate) {
        String sDate = Long.toString(lDate);
        int iYear = Integer.parseInt(sDate.substring(0,4));
        int iMonth = Integer.parseInt(sDate.substring(4,6)) -1;
        int iDay = Integer.parseInt(sDate.substring(6,8));
        int iHour = Integer.parseInt(sDate.substring(8,10));
        int iMinute = Integer.parseInt(sDate.substring(10,12));
        Calendar cal = Calendar.getInstance();
        cal.set(iYear, iMonth, iDay, iHour, iMinute);
        return cal;
    }
}
