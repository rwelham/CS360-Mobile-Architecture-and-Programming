package com.example.eventtrackingremywelham;

public class User {
    private String username;
    private String password;
    private int smsPerm;

    public User() {
        username = null;
        password = null;
        smsPerm = 0;
    }

    public User(String newUsername){
        username = newUsername;
        password = null;
    }

    public User(String newUsername, String newPassword) {
        username = newUsername;
        password = newPassword;
    }

    public String getUsername(){
        return username;
    }

    // 1 is true for permission, anything else is false
    public boolean getSmsPerm(){
        return smsPerm == 1;
    }

    protected String getPassword(){
        return password;
    }

    public void setUsername(String user){
        this.username = user;
    }

    public void setPassword(String pass){
        this.password = pass;
    }

    public void setSmsPerm(int smsPerm){
        this.smsPerm = smsPerm;
    }
}
