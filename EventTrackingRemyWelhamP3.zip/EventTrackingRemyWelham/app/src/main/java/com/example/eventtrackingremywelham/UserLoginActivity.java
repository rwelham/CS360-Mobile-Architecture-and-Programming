package com.example.eventtrackingremywelham;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

public class UserLoginActivity extends AppCompatActivity {

    // variables for edit text and buttons
    private EditText usernameEdit, passwordEdit;
    private Button loginBtn, signUpBtn;
    private EventTrackerDatabase eventDB;
    private String registerUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // initializing edit text and buttons
        usernameEdit = findViewById(R.id.editTextUsername);
        passwordEdit = findViewById(R.id.editTextPassword);
        loginBtn = findViewById(R.id.btnLogin);
        signUpBtn = findViewById(R.id.btnSignUp);

        ActivityResultLauncher<Intent> startRegistration = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if(result.getResultCode() == AppCompatActivity.RESULT_OK) {
                        Intent data = result.getData();
                        registerUser = data.getStringExtra("regUsername");
                        if (registerUser != null) {
                            closeActivity(registerUser);
                        }
                    }
                }
        );

        // adding onClick listener for login button
        loginBtn.setOnClickListener(v -> authUser());

        // register activity on button press
        signUpBtn.setOnClickListener(v -> {
            Intent intent = new Intent(UserLoginActivity.this, UserRegisterActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startRegistration.launch(intent);
        });

        eventDB = EventTrackerDatabase.getInstance(getApplicationContext());
    }

    public void authUser(){
        boolean authenticated;
        User user = new User(usernameEdit.getText().toString(), passwordEdit.getText().toString());
        authenticated = eventDB.authenticateUser(user);

        if(!authenticated) {
            Toast toast = Toast.makeText(this, "Invalid Username/Password", Toast.LENGTH_SHORT);
            toast.show();
        } else closeActivity(user.getUsername());
    }

    public void closeActivity(String username) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("authUsername", username);
        setResult(Activity.RESULT_OK, intent);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        loginBtn.setOnClickListener(null);
        signUpBtn.setOnClickListener(null);
    }
}