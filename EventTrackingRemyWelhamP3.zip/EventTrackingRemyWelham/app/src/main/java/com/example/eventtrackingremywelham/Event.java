package com.example.eventtrackingremywelham;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Event {
    private int id;
    private String title;
    private Calendar cal;
    private String description;
    private String eventUser;

    public Event(){
        id = 0;
        title = null;
        cal = null;
        description = null;
        eventUser = null;
    }

    public Event(String title, Calendar cal, String description, String eventUser) {
        this.title = title;
        this.cal = cal;
        this.description = description;
        this.eventUser = eventUser;
    }

    public void setId(int id){
        this.id = id;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setDate(Calendar cal){
        this.cal = cal;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setEventUser(String user){
        this.eventUser = user;
    }

    public Calendar getDate() {
        return cal;
    }

    public String getStringDate() {
        SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
        return format.format(cal.getTime());
    }

    public String getEventUser() {
        return eventUser;
    }

    public String getDescription() {
        return description;
    }

    public String getTitle() {
        return title;
    }

    public int getId() {
        return id;
    }
}
