package com.example.eventtrackingremywelham;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import java.util.List;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.ViewHolder> {

    private List<Event> eventData;
    private LayoutInflater layoutInflater;
    private ItemClickListener itemClickListener;

    EventRecyclerAdapter(Context context, List<Event> data) {
        this.layoutInflater = LayoutInflater.from(context);
        this.eventData = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int vType) {
        View view = layoutInflater.inflate(R.layout.activity_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return eventData.size();
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int pos){
        Event event = eventData.get(pos);
        holder.eventName.setText(event.getTitle());
        holder.eventDate.setText(event.getStringDate());
        holder.eventId = event.getId();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private int eventId;
        TextView eventName, eventDate;

        ViewHolder(View itemView){
            super(itemView);
            eventName = itemView.findViewById(R.id.tvEventName);
            eventDate = itemView.findViewById(R.id.tvEventDate);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(view, getAdapterPosition(), eventId);
            }
        }
    }

    int getEvent(int id){
        return eventData.get(id).getId();
    }

    void setOnClickListener(ItemClickListener clickListener){
        this.itemClickListener = clickListener;
    }

    public interface ItemClickListener{
        void onItemClick(View view, int pos, int eventId);
    }
}
