package com.example.eventtrackingremywelham;
// androidx imports
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
//android imports
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.Toast;
import android.os.Bundle;
// java imports
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements EventRecyclerAdapter.ItemClickListener {

    private EventTrackerDatabase eventDB;
    private List<Event> eventList;
    private User user;
    private String username;
    EventRecyclerAdapter adapter;
    final int REQUEST_SMS = 0;
    private String smsPermission = Manifest.permission.SEND_SMS;
    private Calendar systemTime;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get username
        Intent intent = getIntent();
        username = intent.getStringExtra("authUsername");

        // welcome message
        Toast toast = Toast.makeText(this, "Welcome to the Event Tracking App", Toast.LENGTH_SHORT);
        toast.show();

        // get events from database
        eventDB = EventTrackerDatabase.getInstance(getApplicationContext());
        user = eventDB.getUser(username);
        eventList = eventDB.getEvents(username);

        // get sms permissions
        checkSMSPerms(); // method created below
        smsPermission = Manifest.permission.SEND_SMS;

        // check if current date is equal to event date
        systemTime = Calendar.getInstance();
        sendSMS(); // method created below
    }

    // open ViewEvent on selected event
    public void onItemClick(View view, int pos, int eventID){
        Toast.makeText(this,
                "You clicked ID: " + eventID + " on row number " + pos,
                Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, EventView.class);
        intent.putExtra("eventID", eventID);
        startActivity(intent);
    }

    // open add event on click
    public void addEventClick(View view){
        Intent intent = new Intent(this, AddEvent.class);
        intent.putExtra("authUsername", username);
        startActivity(intent);
    }

    @Override
    protected void onResume(){
        super.onResume();
        eventList = eventDB.getEvents(username);

        // create recyclerView
        RecyclerView recyclerView = findViewById(R.id.rcEvents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventRecyclerAdapter(this, eventList);
        adapter.setOnClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    //get user permission for SMS
    private void checkSMSPerms(){
        if (!user.getSmsPerm()) {
            ActivityCompat.requestPermissions(this, new String[] {smsPermission}, REQUEST_SMS);
            user.setSmsPerm(1);
        }
    }

   // sending a toast instead of SMS to test
    public void sendSMS(){
        if(!eventList.isEmpty()) {
            for(Event event : eventList){
                if(systemTime.get(Calendar.YEAR) == event.getDate().get(Calendar.YEAR) &&
                        systemTime.get(Calendar.MONTH) == event.getDate().get(Calendar.MONTH) &&
                        systemTime.get(Calendar.DAY_OF_MONTH) == event.getDate().get(Calendar.DAY_OF_MONTH)){
                    if(ContextCompat.checkSelfPermission(this, smsPermission) ==
                            PackageManager.PERMISSION_GRANTED){
                        String message = "Your event is today!";
                        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
                        toast.show();
                    }
                }
            }
        }
    }


}