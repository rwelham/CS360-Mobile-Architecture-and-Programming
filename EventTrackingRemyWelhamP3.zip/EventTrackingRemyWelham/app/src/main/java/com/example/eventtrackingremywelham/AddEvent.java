package com.example.eventtrackingremywelham;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class AddEvent extends AppCompatActivity {

    private EventTrackerDatabase eventDB;
    private String username;
    private EditText eTitle, eYear, eMonth, eDay, eHour, eMinute;
    private EditText eDescription;
    private Button addButton, cancelButton;
    private String sYear, sMonth, sDay, sHour, sMinute;
    private int iYear, iMonth, iDay, iHour, iMinute;
    private Calendar userDate;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event );

        Intent intent = getIntent();
        username = intent.getStringExtra("authUsername");
        eventDB = EventTrackerDatabase.getInstance(getApplicationContext());

        eTitle = findViewById(R.id.eventTitle);
        eYear = findViewById(R.id.eventYear);
        eMonth = findViewById(R.id.eventMonth);
        eDay = findViewById(R.id.eventDay);
        eHour = findViewById(R.id.eventHour);
        eMinute = findViewById(R.id.eventMinute);
        eDescription = findViewById(R.id.eventDescription);
        addButton = findViewById(R.id.buttonAddEvent);
        cancelButton = findViewById(R.id.buttonCancel);

        eTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eTitle = findViewById(R.id.eventTitle);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eYear.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eYear = findViewById(R.id.eventYear);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eMonth.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eMonth = findViewById(R.id.eventMonth);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eDay.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eDay = findViewById(R.id.eventDay);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eHour.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eHour = findViewById(R.id.eventHour);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eMinute.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eMinute = findViewById(R.id.eventMinute);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        eDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                eDescription = findViewById(R.id.eventDescription);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
                });
    }

    public void addEvent(View view){
        if(!isEmpty(eTitle) && isValidDate(eYear, eMonth, eDay, eHour, eMinute) && !isEmpty(eDescription)){
            Event event = new Event(eTitle.getText().toString(), userDate, eDescription.getText().toString(), username);
            eventDB.addEvent(event);
            finish();
        }
    }

    public void cancelEvent(View view){
        finish();
    }

    public boolean isEmpty(EditText editText){
        String eventString = editText.getText().toString();
        return eventString.matches("");
    }

    // check length of range
    public boolean isValidDate(EditText year, EditText month, EditText day, EditText hour, EditText minute){
        Calendar systemTime = Calendar.getInstance();

        if(sYear.length() != 4){
            Toast toast = Toast.makeText(this, "Year is 4 digits", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        if((sMonth.length() > 2) || (sMonth.length() < 0) || (iMonth > 12) || (iMonth < 1)){
            Toast toast = Toast.makeText(this, "Month is 2 digits between 1-12", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        if(sDay.length() > 2 || sDay.length() < 0 || iDay > 31 || iDay < 1){
            Toast toast = Toast.makeText(this, "Day is 2 digits between 1-31", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        if(sHour.length() > 2 || sHour.length() < 0 || iHour > 23 || iHour < 1){
            Toast toast = Toast.makeText(this, "Hour is 2 digits between 1-23", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        if(sMinute.length() > 2 || sMinute.length() < 0 || iMinute > 59 || iMinute < 1){
            Toast toast = Toast.makeText(this, "Minute is 2 digits between 1-59", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }

        Calendar userDate = Calendar.getInstance();
        userDate.set(iYear, iMonth, iDay, iHour, iMinute);
        // check that date hasn't past
        if(userDate.getTimeInMillis() < systemTime.getTimeInMillis()){
            Toast toast = Toast.makeText(this, "This date has already past", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        this.userDate = userDate;
        Toast toast = Toast.makeText(this, "Event added", Toast.LENGTH_SHORT);
        toast.show();
        return true;
    }

    private int convertStringtoInt(String string){
        try{
            return Integer.parseInt(string);
        } catch (Exception e){
            return 0;
        }
    }
}
