package com.example.eventtrackingremywelham;

import androidx.activity.result.IntentSenderRequest;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

// layout for this activity @ activity_event_view.xml

public class EventView extends AppCompatActivity {

    private EventTrackerDatabase eventDB;
    private Event event;
    private TextView eTitle, eDate, eDesc;
    private int eID;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);

        Intent intent = getIntent();
        eID = intent.getIntExtra("eventID", -1);
        eventDB = EventTrackerDatabase.getInstance(getApplicationContext());

        eTitle = findViewById(R.id.evEventTitle);
        eDate = findViewById(R.id.evEventDate);
        eDesc = findViewById(R.id.evEventDescription);
    }

    @Override
    protected void onResume(){
        super.onResume();
        event = eventDB.getEvent(eID);
        eTitle.setText(event.getTitle());
        eDate.setText(event.getStringDate());
        eDesc.setText(event.getDescription());
    }

    // delete event on click
    public void deleteEvent(View view){
        eventDB.deleteEvent(event);
        finish();
    }

    // finish current activity with no change
    public void goBack(View view){
        finish();
    }

}
